#!/bin/bash

python3 ../../../jb_2016_INT.py -s -c config.json -r 30
# Or
# python ../../../jb_2016_INT.py -s -c config.json -r 30
